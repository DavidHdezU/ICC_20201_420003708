package chess.pieces;

public enum PiecesTypeEnum {
    ROOK, QUEEN, PAWN, HORSE, BISHOP, KING, EMPTY
}