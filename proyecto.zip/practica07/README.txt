INSTRUCCIONES PARA COMPILAR Y EJECUTAR

1.- Abrir la carpeta: practica07/
2.- Colocarse en una terminal sobre la carpeta: ejecutar/
3.- Para compilar y ejecutar el programa escribir en la terminal: gradle run
4.- Esto deberia de compilarnos todo sin ningún error y nos deberia mostrar los movimientos legales que nuestras piezas de Torre y Reina podrían hacer


INSTRUCTIONS FOR COMPILING AND EXECUTING

1.- Open the folder practica07/
2.- Open a terminal and go to the folder: ejecutar/
3.- To compile and excute the programm write in the terminal: gradle run
4.- This should compile everything without a mistake y it should show us the legal moves that our Queen and Rook pieces could do
